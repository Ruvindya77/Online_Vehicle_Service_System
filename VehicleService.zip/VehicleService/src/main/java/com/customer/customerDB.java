package com.customer;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class customerDB {
public static boolean insertCustomer(String name, String email, String phone, String password) {
		
		boolean isSuccess = false;
		
		String url = "jdbc:mysql://localhost:3306/vehicleservice";
		String user = "root";
		String pass = "happy123";
		
		try {
		Class.forName("com.mysql.jdbc.Driver");
		Connection con = DriverManager.getConnection(url, user, pass);
		Statement stat = con.createStatement();
		String sql = "insert into customer values (0,'"+name+"', '"+email+"', '"+phone+"', '"+password+"' )";
		int rs = stat.executeUpdate(sql);
		
		if(rs > 0) {
			isSuccess = true;
		}
		else {
			isSuccess = false;
		}
		
	    }
		catch(Exception e ) {
			e.printStackTrace();
			}
		return isSuccess;
		}

public static List<customer> validate(String email, String password){
	ArrayList<customer> cus = new ArrayList<>();
	
		String url = "jdbc:mysql://localhost:3306/vehicleservice";
		String user = "root";
		String pass = "happy123";
		
		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection(url, user, pass);
			Statement stat = con.createStatement();
			String sql = "SELECT * FROM customer WHERE email = '"+email+"' and password = '"+password+"'";
			ResultSet rs = stat.executeQuery(sql);
			
			if(rs.next()) {
				
				int id = rs.getInt(1);
				String name = rs.getString(2);
				String cemail = rs.getString(3);
				String phone = rs.getString(4);
				String cpass = rs.getString(5);
				
				customer c = new customer(id, name, cemail, phone, cpass);
				cus.add(c);
			}
			else {
				
			}
			
		    }
			catch(Exception e ) {
				e.printStackTrace();
				}
	
	return cus;
}
public static boolean updateCustomerProfile(String name, String email, String phone, String password) {
    boolean isSuccess = false;

    String url = "jdbc:mysql://localhost:3306/vehicleservice";
    String user = "root";
    String pass = "happy123";

    try (Connection con = DriverManager.getConnection(url, user, pass)) {
        String sql = "UPDATE customer SET name = ?, phone = ?, password = ? WHERE email = ?";
        try (PreparedStatement pstmt = con.prepareStatement(sql)) {
            pstmt.setString(1, name);
            pstmt.setString(2, phone);
            pstmt.setString(3, password);
            pstmt.setString(4, email);

            int rowsUpdated = pstmt.executeUpdate();
            if (rowsUpdated > 0) {
                isSuccess = true;
            }
        }
    } catch (SQLException e) {
        e.printStackTrace();
    }
    return isSuccess;
}
public static List<customer> getCustomerByEmail(String email) {
    List<customer> cusDetails = new ArrayList<>();

    String url = "jdbc:mysql://localhost:3306/vehicleservice";
    String user = "root";
    String pass = "happy123";

    try {
        Class.forName("com.mysql.jdbc.Driver");
        Connection con = DriverManager.getConnection(url, user, pass);
        Statement stat = con.createStatement();
        String sql = "SELECT * FROM customer WHERE email = '" + email + "'";
        ResultSet rs = stat.executeQuery(sql);

        while (rs.next()) {
            int id = rs.getInt(1);
            String name = rs.getString(2);
            String cemail = rs.getString(3);
            String phone = rs.getString(4);
            String cpass = rs.getString(5);

            customer c = new customer(id, name, cemail, phone, cpass);
            cusDetails.add(c);
        }

        con.close();
    } catch (Exception e) {
        e.printStackTrace();
    }

    return cusDetails;
}


	
}

