package com.customer;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class OTPVerificationServlet
 */
@WebServlet("/OTPVerificationServlet")
public class OTPVerificationServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Get OTP entered by the user
        String userOTP = request.getParameter("otp");

        // Get OTP saved in the session
        String sessionOTP = (String) request.getSession().getAttribute("otp");

        // Compare user OTP with session OTP
        if (userOTP.equals(sessionOTP)) {
            // OTP verification successful, proceed with registration
            // Call customerDB.insertCustomer() here
            // Redirect to success page
            response.sendRedirect("success.jsp");
        } else {
            // OTP verification failed, display error message
            // Redirect to error page or registration page with error message
            response.sendRedirect("error.jsp");
        }
    }
}
