package com.customer;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;


public class SignIn extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String email = request.getParameter("email");
        String password = request.getParameter("password");

        try {
            List<customer> cusDetails = customerDB.validate(email, password);
            if (!cusDetails.isEmpty()) {
                // User is authenticated, set session attribute
            	// After successful authentication
            	HttpSession session = request.getSession();
            	session.setAttribute("loggedInUser", cusDetails.get(0)); // Store customer object in session


                // Forward the user to the profile page
                RequestDispatcher dispatcher = request.getRequestDispatcher("HomePage.jsp");
                dispatcher.forward(request, response);
            } else {
                // Authentication failed, redirect back to login page with an error message
                request.setAttribute("errorMessage", "Invalid email or password");
                RequestDispatcher dis = request.getRequestDispatcher("login.jsp");
                dis.forward(request, response);
            }
        } catch (Exception e) {
            e.printStackTrace();
            // Handle any exception that might occur during the authentication process
            response.sendRedirect("error.jsp");
        }
    }
}


