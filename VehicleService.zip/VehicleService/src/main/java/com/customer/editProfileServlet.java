package com.customer;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public class editProfileServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Retrieve form parameters
        String name = request.getParameter("name");
        String email = request.getParameter("email");
        String phone = request.getParameter("phone");
        String password = request.getParameter("password"); // Added password parameter
        
        // Update profile details in the database
        boolean isSuccess = customerDB.updateCustomerProfile(name, email, phone, password); // Updated method call
        
        if(isSuccess) {
            // Retrieve the current user object from the session
            HttpSession session = request.getSession(false);
            if(session != null) {
                customer loggedInUser = (customer) session.getAttribute("loggedInUser");
                if(loggedInUser != null) {
                    // Update the user object with new details
                    loggedInUser.setName(name);
                    loggedInUser.setEmail(email);
                    loggedInUser.setPhone(phone);
                    // Set the updated user object back to the session
                    session.setAttribute("loggedInUser", loggedInUser);
                }
            }
            // Profile updated successfully
            response.sendRedirect("userProfile.jsp");
        } else {
            // Failed to update profile
            // You can handle this case as per your requirement
            // For example, display an error message
            response.sendRedirect("error.jsp");
        }
    }
}
