package com.customer;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/customerReg")
public class customerReg extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String name = request.getParameter("name");
        String email = request.getParameter("email");
        String phone = request.getParameter("phone");
        String password = request.getParameter("password");
        
        // Generate OTP
        String otp = OTPGenerator.generateOTP(6); // Generate 6-digit OTP
        
        // Save OTP to session for verification
        request.getSession().setAttribute("otp", otp);
        
        // Send OTP via Email
        OTPService.sendOTP(email, otp);
        
        // Forward to OTP verification page
        RequestDispatcher dispatcher = request.getRequestDispatcher("otpVerification.jsp");
        dispatcher.forward(request, response);
        
        // Check if registration was successful
        boolean registrationSuccessful = customerDB.insertCustomer(name, email, phone, password);
        
        // Forward to appropriate page based on registration success
        if (registrationSuccessful) {
            RequestDispatcher successDispatcher = request.getRequestDispatcher("success.jsp");
            successDispatcher.forward(request, response);
        } else {
            RequestDispatcher failureDispatcher = request.getRequestDispatcher("failure.jsp");
            failureDispatcher.forward(request, response);
        }
    }
}
