package com.customer;

import java.util.Random;

public class OTPGenerator {
    // Generate OTP method
    public static String generateOTP(int length) {
        // Define characters allowed in the OTP
        String numbers = "0123456789";

        // Using StringBuilder to efficiently build the OTP
        StringBuilder sb = new StringBuilder();

        // Initialize random number generator
        Random random = new Random();

        // Generate OTP of specified length
        for (int i = 0; i < length; i++) {
            // Get a random index from the numbers string
            int index = random.nextInt(numbers.length());

            // Append the character at the random index to the OTP
            sb.append(numbers.charAt(index));
        }

        // Return the generated OTP as a string
        return sb.toString();
    }
}
